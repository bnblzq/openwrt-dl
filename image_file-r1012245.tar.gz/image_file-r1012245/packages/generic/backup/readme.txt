This partition is backup partition.
