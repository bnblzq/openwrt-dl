#!/bin/bash
export FS_SRC=$1
export KERNEL_SOURCE=$2
export TOOLCHAIN_PATH="../../../../toolchain/usr/local/arm-2013.11/bin/"

pushd $FS_SRC
./build-ufsd.sh
popd
