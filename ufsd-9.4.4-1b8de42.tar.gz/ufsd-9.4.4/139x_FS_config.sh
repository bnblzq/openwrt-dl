#!/bin/bash
export FS_SRC=$1
export KERNEL_SOURCE=$2
export TOOLCHAIN_PATH=$3

pushd $FS_SRC
./build-ufsd.sh
popd

